class Animal  
  def breathe  
  end  
end  
  
class Cat < Animal  
  def speak  
    puts "Miao~~"  
  end  
end  
