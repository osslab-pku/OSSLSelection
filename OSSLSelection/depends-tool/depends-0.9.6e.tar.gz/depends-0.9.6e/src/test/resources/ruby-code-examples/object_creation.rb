class M
end

class T
   def foo
       m = M.new
   end
end
