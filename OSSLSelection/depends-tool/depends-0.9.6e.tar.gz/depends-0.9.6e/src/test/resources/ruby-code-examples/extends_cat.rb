require 'extends_animal'

class Cat < Animal  
  def speak  
    puts "Miao~~"  
  end  
end  
