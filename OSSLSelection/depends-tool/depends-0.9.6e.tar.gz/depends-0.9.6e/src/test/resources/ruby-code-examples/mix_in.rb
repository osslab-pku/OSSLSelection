module ToBeMixin
end

module MixedIn
  include ToBeMixin
end
