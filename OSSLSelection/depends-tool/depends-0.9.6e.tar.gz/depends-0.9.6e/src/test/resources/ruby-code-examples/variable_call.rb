class Class
  def function
  end
end

def test
  v = Class.new
  v.function
end