module L
    module M::N
    end
end

module A
  module B
  end
end


module X::Y
    module Z
    end
end

