class Animal  
  def breathe  
  end  
end  

