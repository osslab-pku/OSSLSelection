def foo (v)
end

def bar (t)
end

def test
  a = 1
  foo bar a
end
