def called
  return "A"
end

def called_from
  called
end