require 'require_2'

require_relative '../ruby-code-examples/require_2.rb'
