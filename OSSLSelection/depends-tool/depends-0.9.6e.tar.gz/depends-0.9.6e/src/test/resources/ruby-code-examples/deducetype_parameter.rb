class Type1
  def f1_1
  end
end

class Type2
  def f2_1
  end
end

class Type3
  def f1_1
  end
  def f3_1
  end
end

def test(t1)
  t1.f1_1
end