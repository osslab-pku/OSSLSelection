class Class
  def foo
  end
end

var = Class.new
var.foo
