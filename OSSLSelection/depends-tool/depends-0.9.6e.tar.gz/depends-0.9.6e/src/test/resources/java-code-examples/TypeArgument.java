import java.util.ArrayList;

import javax.xml.bind.annotation.XmlRootElement;

import depends.format.json.JCellObject;

class JCellObject{
	
}
public class JDepObject {
    private ArrayList<JCellObject> cells;
}