class A{
	A(){}
}

public class InheritTest extends A{
	
}