package a;
public class InternalClass {
	class Internal{
		
	}
}