package x;
class TypeInferUnderSamePackageA{
	TypeInferUnderSamePackageB.SubType v;
}