import b.*;
public class X{
	void foo() {
		Object x = new B();
	}
}