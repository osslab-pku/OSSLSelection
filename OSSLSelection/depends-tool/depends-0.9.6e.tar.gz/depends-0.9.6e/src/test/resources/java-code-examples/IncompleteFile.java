protected static Logger log = Logger.getLogger(InsightManagerInitializer222.class);
