package x;
class TypeInferUnderSamePackageB{
	class SubType {
		
	}
}