public class FunctionParameters {
	public void func_without_parameter() {
	}
	public void function_with_one_parameter(Integer a) {
		
	}
	public void function_with_two_parameter(Integer a, String b) {
		
	}
	public void function_with_parameters_same_type(Integer a, String b, Integer c) {
		
	}
}