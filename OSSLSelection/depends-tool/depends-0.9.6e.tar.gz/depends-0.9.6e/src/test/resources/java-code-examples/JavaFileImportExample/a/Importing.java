package a;
import b.*;

class Importing extends B{

}