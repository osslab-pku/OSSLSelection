class MyHashMap<T1, T2>{
	
}

class MyList<T> {
	
}

class MyArray<T>{
	
}

class GenericTypeEmbededTest{
	MyHashMap<String, MyList<MyArray<Integer>> > data; 
}