class A extends C{
	A(){
		
		this.a = 1;
		this.foo();
		foo();
	}
	
}

class B extends A{
	
}


class C extends B{
	
}

