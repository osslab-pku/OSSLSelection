public class A{
	void foo() {
		Object x = new b.B();
	}
}