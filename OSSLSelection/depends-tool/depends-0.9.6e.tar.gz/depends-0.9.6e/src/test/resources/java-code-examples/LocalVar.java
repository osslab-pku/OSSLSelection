
public class LocalVar {
	String a;
	void foo(String b) {
		String a;
	}
}