
public class FieldVar {
	String a;
	public String b,c;
}