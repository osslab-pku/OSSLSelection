package b;

class B{

}