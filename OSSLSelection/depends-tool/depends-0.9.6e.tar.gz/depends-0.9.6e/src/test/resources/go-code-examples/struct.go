package test
type Books struct {
   title string
   author string
   subject string
   book_id int
}
