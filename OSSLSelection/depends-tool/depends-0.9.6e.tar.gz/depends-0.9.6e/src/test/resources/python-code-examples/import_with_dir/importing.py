from .imported_a import foo
from . import imported_a

def foo():
    pass 
