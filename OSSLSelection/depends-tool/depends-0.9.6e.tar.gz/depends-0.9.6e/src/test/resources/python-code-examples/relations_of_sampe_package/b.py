def bar():
  foo()
