from import_with_dir import imported_a

def foo():
    pass 
