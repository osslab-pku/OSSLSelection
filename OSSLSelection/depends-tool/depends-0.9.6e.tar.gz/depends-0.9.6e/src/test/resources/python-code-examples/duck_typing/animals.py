class Duck:
    def quack(self):
        print "Quaaaaaack!"
 
class Bird:
    def quack(self):
        print "bird imitate duck."
 
class Doge:
    def quack(self):
        print "doge imitate duck."
