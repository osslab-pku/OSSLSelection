class ShouldBeOverride:
  def remove(self):
    pass
  def add(self):
    pass
  def special(self):
    pass

def test(t1):
  t1.remove(self)
  t1.add(self)
  
def test2(t1):
  t1.remove(self)
  t1.add(self)  
  t1.special(self)
