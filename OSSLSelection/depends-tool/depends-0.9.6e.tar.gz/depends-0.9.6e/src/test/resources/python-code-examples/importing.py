import imported_a

imported_a.foo()
