def foo():
  pass
