def foo():
  global global_var
  global_var = 0     
  pass
