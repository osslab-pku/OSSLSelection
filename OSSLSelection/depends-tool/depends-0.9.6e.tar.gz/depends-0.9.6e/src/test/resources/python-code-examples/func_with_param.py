class X:
  def foo():
    pass
  
class Y:
  def bar(x):
     x.foo()
     

