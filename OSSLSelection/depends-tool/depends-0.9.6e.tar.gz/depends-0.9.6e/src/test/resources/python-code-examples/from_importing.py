from imported_a import foo

foo()
