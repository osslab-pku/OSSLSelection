def bar():
  global global_var
  global_var =  1    
  pass
