def in_the_forest(duck):
    duck.quack()
