import pkg.imported

pkg.imported.foo()

