from import_of_same_dir.pkg import a

def test():
  a.foo()
  pass
