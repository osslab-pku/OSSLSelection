def foo(a,b):
     a = b

def bar(a,b):
     a = b

