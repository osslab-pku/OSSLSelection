def foo():
  pass

from core import deco,C

