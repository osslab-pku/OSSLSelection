from pkg.core import c

c.foo()
