import imported_a as t

t.foo()
