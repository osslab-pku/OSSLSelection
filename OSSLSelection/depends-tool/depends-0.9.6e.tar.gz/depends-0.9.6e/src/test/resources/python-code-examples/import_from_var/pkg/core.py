class Core(object):
  def foo(self):
    pass

c = Core()

