class Type1:
  def f1_1():
    pass


def test(t1):
  t1.f1_1()
  t2 = t1

