class Bar():
  pass

  
def t1():
  raise Bar()


def t2():
  return Bar()
