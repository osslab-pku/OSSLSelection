class Bar():
  pass

def foo():
  b = Bar()

