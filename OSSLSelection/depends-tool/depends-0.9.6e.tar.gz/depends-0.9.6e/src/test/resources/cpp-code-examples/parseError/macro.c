
AP_DECLARE(void) ap_regcomp_set_default_cflags(int cflags);