class A{
};

class C{
};
class B: public A, C{

} ;