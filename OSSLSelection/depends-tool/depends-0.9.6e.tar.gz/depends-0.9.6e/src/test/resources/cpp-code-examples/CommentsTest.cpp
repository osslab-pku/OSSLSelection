#include <a.h>

//This is test 1
void foo();


//this a 2 lines comments
// line 2 
void bar();


/**this is a doxygen comments */
void foo1();


/* this is a comments with 1 line gap */

void bar1();

/* this is a 2 line comments 
line 2*/

/* this is a 2 joint comments -1 */
/* this is a 2 joint comments -2 */
void foo3();



