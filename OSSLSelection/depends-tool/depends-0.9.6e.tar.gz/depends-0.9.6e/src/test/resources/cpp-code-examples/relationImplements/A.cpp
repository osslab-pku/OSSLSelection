#include "A.h"

void foo(){

}
