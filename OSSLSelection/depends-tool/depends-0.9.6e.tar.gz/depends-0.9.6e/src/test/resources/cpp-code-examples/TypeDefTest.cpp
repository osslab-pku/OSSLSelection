typedef int MyInt;

void foo(MyInt a){
}