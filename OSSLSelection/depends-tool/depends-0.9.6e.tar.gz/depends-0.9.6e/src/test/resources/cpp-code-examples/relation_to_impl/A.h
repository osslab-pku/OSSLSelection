#ifndef A_H
#define A_H

void foo();
extern int x;
#endif

