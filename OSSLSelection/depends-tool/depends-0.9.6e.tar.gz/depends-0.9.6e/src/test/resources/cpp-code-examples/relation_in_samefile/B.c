static void register_hooks()
{
}
