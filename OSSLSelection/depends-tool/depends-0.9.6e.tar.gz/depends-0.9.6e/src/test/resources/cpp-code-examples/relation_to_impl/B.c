#include "A.h"
void bar(){
    foo();
}

void baz(){
x++;
}

void qux(){
int x=0;
x++;
}
