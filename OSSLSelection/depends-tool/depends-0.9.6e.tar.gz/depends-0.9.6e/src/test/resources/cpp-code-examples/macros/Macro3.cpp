#include "MacroMediate.h"
CLASS Macro3{

int bar(){
return 0;
}
END_CLASS
