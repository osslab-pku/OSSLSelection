typedef enum {
    item1, item2
} Enum;


class C{
    Enum e;
};


