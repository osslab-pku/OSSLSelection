#include "A.h"
int x;
void foo()
{
}
