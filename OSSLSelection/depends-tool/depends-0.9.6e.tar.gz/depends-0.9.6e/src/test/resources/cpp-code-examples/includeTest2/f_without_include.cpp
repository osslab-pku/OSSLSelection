void foo2(){
bar();
}
