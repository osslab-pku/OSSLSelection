#include "Macro.h"
CLASS Macro{
END_CLASS

int main(){
return 0;
}
