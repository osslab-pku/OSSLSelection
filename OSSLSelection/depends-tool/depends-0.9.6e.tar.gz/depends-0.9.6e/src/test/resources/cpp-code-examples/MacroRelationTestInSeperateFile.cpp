#include "MacroRelationTestInSeperateFile.h"

void foo(){
   int i = A;
}

void bar(){
   int t=MULTI(2,3);
}


void three(){

}

