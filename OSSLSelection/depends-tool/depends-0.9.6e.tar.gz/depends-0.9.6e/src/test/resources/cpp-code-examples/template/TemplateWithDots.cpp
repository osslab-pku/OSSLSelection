template <typename ...T>
void foo(){
	int t;
    MyClass<T...> t2;
}