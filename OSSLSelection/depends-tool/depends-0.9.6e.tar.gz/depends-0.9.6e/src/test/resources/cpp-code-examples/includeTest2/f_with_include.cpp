#include "f0.cpp"
void foo(){
bar();
}
