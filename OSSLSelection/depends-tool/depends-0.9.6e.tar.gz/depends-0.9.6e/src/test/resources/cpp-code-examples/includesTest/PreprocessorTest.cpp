#include <abc> //el

#define A B \
\
/*t*/TLD //comment 

#undefine T

#define X

#ifndef _ABC_

int a;

//#define _ABC
#line 1

#endif


#ifndef _TLD00_A_ //comments



#define _ABC //comments

#define AREA(a,b)  (a*b)
#endif //(_TLD00A)


#define T