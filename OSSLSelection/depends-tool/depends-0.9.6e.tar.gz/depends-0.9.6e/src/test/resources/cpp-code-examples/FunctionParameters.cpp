class FunctionParameters {
public:
	void func_without_parameter() {
	}
	void function_with_one_parameter(int a) {
		
	}
	void function_with_two_parameter(int a, double b) {
		
	}
	void function_with_parameters_same_type(int a, double b, int c) {
		
	}
};