#ifdef MACRO
#include "fx.h"
#include "../includeTest3/fy.h"
#endif

