#define A 2
#define MULTI(a,b)   (a*b)
#define MULTI_MULTI(a,b) (MULTI(a,b)*MULTI(a,b))

void bar(){
   int t=MULTI(2,3);
}


void three(){

}

