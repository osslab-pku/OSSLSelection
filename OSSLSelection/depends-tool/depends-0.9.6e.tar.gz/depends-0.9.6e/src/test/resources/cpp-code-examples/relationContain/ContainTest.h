#include "BeContained.h"

class Member{
};

class UnderTest{
    Member m;
    BeContained m2;
};
