static const char sch2[] = "ac" ;


static const char sch[] = "{\"type\": \"record\"";

static const char sch2[] = "aaa"  ;


asm (
"abc""123"
);

  
static const char sch[] = "{\"type\": \"record\","
    "\"name\":\"ComplexInteger\", \"fields\": ["
        "{\"name\":\"re\", \"type\":\"long\"},"
        "{\"name\":\"im\", \"type\":\"long\"}"
    "]}";