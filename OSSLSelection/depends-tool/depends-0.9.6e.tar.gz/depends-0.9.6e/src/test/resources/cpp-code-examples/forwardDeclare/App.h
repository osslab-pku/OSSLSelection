class Mutex;

class App{
public:
void foo();
void bar();
private:
Mutex* mutex;
};
