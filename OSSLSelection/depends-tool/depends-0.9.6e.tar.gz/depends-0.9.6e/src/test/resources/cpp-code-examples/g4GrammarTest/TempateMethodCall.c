   
      void testWriteGeneric() {
        GenericRecord& r = c.value<GenericRecord>();
    }
 
 void methodcallWith2ExpressionList_NOT_FAMILAR(){
   int start = boost::random::uniform_int_distribution<>( 0, 2 * length / splits)(random);
 }
 
