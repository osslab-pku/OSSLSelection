(void)(int) getFunction(){
    return 0;
}
