class BeContained{
};
