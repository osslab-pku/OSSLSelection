#include "Macro.h"
CLASS Macro2{
END_CLASS

int bar(){
return 0;
}
