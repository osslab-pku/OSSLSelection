class Member{
};

class UnderTest{
    Member m;
};
