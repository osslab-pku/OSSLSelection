void knrFunc(a, b, c)
double a;
char b;
{
}
