#ifndef _A_H
#define A_H
void foo();
#endif
