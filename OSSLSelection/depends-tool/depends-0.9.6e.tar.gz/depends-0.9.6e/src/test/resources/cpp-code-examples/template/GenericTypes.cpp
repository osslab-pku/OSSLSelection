
class X{};

template <class T>
class Stack { 

};

Stack<X>   xStack; 


class XStack: public Stack<X> {
};


