template <>
struct hash<DexFieldSpec> {

};

template <>
class ShoudAcceptLiteralTempateArgs<false> {
};