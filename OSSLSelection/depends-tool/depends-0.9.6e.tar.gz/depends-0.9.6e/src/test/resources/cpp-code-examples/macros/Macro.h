#define CLASS class
#define END_CLASS };

void foo(){
}
