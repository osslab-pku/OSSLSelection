typedef struct abc {
} abc_t;
