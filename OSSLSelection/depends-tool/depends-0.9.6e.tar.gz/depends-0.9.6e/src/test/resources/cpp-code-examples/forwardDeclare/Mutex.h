class Mutex{
public:
   void p();
   void v();
};
