class A{
};

typedef A B;

class C: public B{
};

