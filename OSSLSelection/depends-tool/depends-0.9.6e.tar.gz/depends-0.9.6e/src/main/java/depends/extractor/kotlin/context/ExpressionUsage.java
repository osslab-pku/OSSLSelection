package depends.extractor.kotlin.context;

import depends.entity.repo.EntityRepo;
import depends.extractor.kotlin.KotlinHandlerContext;

public class ExpressionUsage {

	public ExpressionUsage(KotlinHandlerContext context, EntityRepo entityRepo) {
		// TODO Auto-generated constructor stub
	}

}
