package depends.entity;

public class FunctionEntityProto  extends FunctionEntity{
	public FunctionEntityProto() {
		super();
	}
    public FunctionEntityProto(GenericName simpleName, Entity parent, Integer id, GenericName returnType) {
		super(simpleName,parent,id,returnType);
	}
}
