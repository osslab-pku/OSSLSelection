package depends;

public class ParameterException extends Exception {
	public ParameterException(String message) {
		super( message);
	}

	private static final long serialVersionUID = 1L;

}
