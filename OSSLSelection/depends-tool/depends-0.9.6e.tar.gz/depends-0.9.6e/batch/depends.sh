#!/bin/sh

exec java -jar depends.jar "$@"

