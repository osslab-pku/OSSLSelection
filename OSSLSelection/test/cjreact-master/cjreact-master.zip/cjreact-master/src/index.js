console.log("babel");
const sum = (num1,num2) => num1+ num2;
let x = sum(1,2);
console.log(x);
console.log(111)