# Wwise Authoring API

This package includes the Wwise Authoring API remote procedure names.

To use waapi in your project

`npm install waapi --save`

see also [waapi-client-ts](https://www.npmjs.com/package/waapi-client-ts)

