// This file is only used on Windows (for building precompiled headers)

#include "stdafx.h"
